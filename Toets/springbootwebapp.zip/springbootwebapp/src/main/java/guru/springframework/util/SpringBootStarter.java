package guru.springframework.util;

public class SpringBootStarter {
    public void StartWebApplication() {
        System.out.println("Error: unreported exception SpringBootNotFoundException; must be caught or declared to be thrown");
        System.exit(1);
    }
}
